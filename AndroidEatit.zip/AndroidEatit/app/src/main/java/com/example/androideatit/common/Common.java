package com.example.androideatit.common;

import com.example.androideatit.Model.User;

public class Common {

    public static User currentUser;
}
